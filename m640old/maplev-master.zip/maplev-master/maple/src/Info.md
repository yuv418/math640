##TOPIC(help) maplev
##HALFLINE an Emacs major-mode for developing Maple code
##
##DESCRIPTION
##- MapleV is an "Emacs" major-mode for developing Maple code.
##  The
